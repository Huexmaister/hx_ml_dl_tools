# hx_ml_dl_tools
Suite de funcionalidades para aprendizaje automatico (dl y ml)

## version 1.1.0

- Modificaciones de bugs de nombres de guardado
- Adicion de version del modelo al diccionario resultante del entrenamiento
- Solucionada la excepcion del SHAP relacionada con backgrounds escasos
- Agregado módulo hx_predictor